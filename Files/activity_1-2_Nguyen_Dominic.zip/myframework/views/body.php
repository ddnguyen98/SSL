<?php
    echo '<h2>The current page is '.$data["pagename"].'</h2>';
?>