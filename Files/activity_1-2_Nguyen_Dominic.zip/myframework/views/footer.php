<?php
    echo '<h2>FOOTER</h2>';
?>