

<div class="container">
<h1>Current user: <?php echo $_SESSION["email"] ?></h1>

<a class='btn btn-primary' href='/profile/logout'>Logout</a>
</div>