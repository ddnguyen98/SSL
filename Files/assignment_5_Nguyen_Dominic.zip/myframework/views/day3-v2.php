<div class="container">
    <!-- Progress bar -->

    <div class="progress my-1">
        <div class="progress-bar" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
    </div>
    <!-- Popover -->
    <button type="button" class="btn btn-lg btn-danger my-1" data-toggle="popover" title="Popover title" data-content="And here's some amazing content. It's very engaging. Right?">
        Click to toggle popover
    </button>

</div>
