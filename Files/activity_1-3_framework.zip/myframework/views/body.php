
<html>

<?php
    echo '<div class="container">';
    echo '<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nec lectus commodo, laoreet urna quis, vulputate ante.
     Morbi mollis in arcu vel luctus. In eu dui lobortis, imperdiet risus non, imperdiet mauris. Nam magna risus, cursus in aliquet in, 
     congue vitae eros. Cras interdum magna purus, sit amet posuere diam maximus ac.</p>';
    echo '</div>';

?>

</html>