

<div class="container">
<h1><?php echo $_SESSION["bio"] ?></h1>

<a class='btn btn-primary' href='/profile/logout'>Logout</a>
</div>